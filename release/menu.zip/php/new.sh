# @author: Lãng Tử Cô Độc
# @website:  https://tinohost.com, https://kienthuclinux.com
# @since: 2020clear
echo ""
echo "====================================================================================="
echo "Menu Board > Manage Nginx > Rebuild Vhost Domain "
echo "/-------------------------/"
echo "- Rebuild Vhost Domain"
echo "/-----------------------------------------------------------------------------------/"


for D in /etc/quicklemp/domains/*; do
if [ -d "${D}" ]; then #If a directory
domain=${D##*/}
domain_alias="www.$domain"
    if [[ $domain == *www* ]]; then
	    domain_alias=${domain/www./''}
    fi
echo "rebuild lai vhost cho domain $domain"          			
php_dir=$(</etc/quicklemp/domains/$domain/php_dir)
user=$(</etc/quicklemp/domains/$domain/user)
php_version=$(</etc/quicklemp/domains/$domain/php_version)
page_speed=$(</etc/quicklemp/domains/$domain/page_speed)
echo ""
php_ver=${php_dir:3}


mkdir -p /etc/nginx/conf.d/addon_confs/$domain/

cp -r /etc/nginx/conf.d/custom/$php_version.conf /etc/nginx/conf.d/addon_confs/$domain/$php_version.conf
cp -r /etc/nginx/conf.d/custom/restrictions-users.conf /etc/nginx/conf.d/addon_confs/$domain/restrictions-users.conf

if ! [ -d "/etc/nginx/conf.d/ssl/$domain/" ] 
then
mkdir -p /etc/nginx/conf.d/ssl/$domain/
openssl req -x509 -nodes -new -sha256 -days 1024 -newkey rsa:2048 -keyout /etc/nginx/conf.d/ssl/$domain/privkey.key -out /etc/nginx/conf.d/ssl/$domain/chain.pem -subj "/C=US/CN=$domain" &>/dev/null
openssl x509 -outform pem -in /etc/nginx/conf.d/ssl/$domain/chain.pem -out /etc/nginx/conf.d/ssl/$domain/fullchain.crt &>/dev/null
server_ip=$(dig -4 TXT +short o-o.myaddr.l.google.com @ns1.google.com | sed -e 's/\"//g')
 ip=$(getent hosts $domain | awk '{ print $1 }');
    wwwdomain=www.$domain
    wwwip=$(getent hosts $wwwdomain | awk '{ print $1 }');    
    mkdir -p /etc/nginx/conf.d/ssl/$domain/	
    echo "$domain point to IP: $ip"        
    echo "$wwwdomain point to IP: $wwwip"

	
	if [ "$ip" = "$server_ip" ]; then
		if [ "$wwwip" = "$server_ip" ]; then
			echo "Setup Let's Enscrypt for $domain ... and $wwwdomain "
			/root/.acme.sh/acme.sh  --issue -w /home/$domain/public_html/ -d $domain -d $wwwdomain -k 4096 --force			
				if [ -f /root/.acme.sh/$domain/$domain.cer ]; then
					echo "Installing SSL for domain $domain, $wwwdomain"
					/root/.acme.sh/acme.sh --installcert -d $domain --keypath /etc/nginx/conf.d/ssl/$domain/privkey.key --fullchainpath /etc/nginx/conf.d/ssl/$domain/fullchain.crt
					echo "SSL installation is complete."
				else
					echo "SSL settings encountered an error, please check again."
				fi		
		else		
			echo "Setup Let's Enscrypt for $domain ... no record exists $wwwdomain "			
			/root/.acme.sh/acme.sh  --issue -w /home/$domain/public_html/ -d $domain -k 4096 --force
			if [ -f /root/.acme.sh/$domain/$domain.cer ]; then
				echo "Installing SSL for domain $domain ."
				/root/.acme.sh/acme.sh --installcert -d $domain --keypath /etc/nginx/conf.d/ssl/$domain/privkey.key --fullchainpath /etc/nginx/conf.d/ssl/$domain/fullchain.crt
				echo "SSL installation is complete."
			else
				echo "SSL settings encountered an error, please check again."
			fi
		fi
	else
	    if [ "$wwwip" = "$server_ip" ]; then
		    read -r -p "$wwwdomain pointing to the VPS IP, $domain has not been returned to IP VPS, You still want to personalize it $wwwdomain ? [y/N] " response
            case $response in
                [yY][eE][sS]|[yY])
				
				echo "SSetup Let's Enscrypt for $wwwdomain ... "
				/root/.acme.sh/acme.sh  --issue -w /home/$domain/public_html/ -d $wwwdomain -k 4096 --force
				if [ -f /root/.acme.sh/$domain/$domain.cer ]; then
					echo "Installing SSL for domain $domain"
					/root/.acme.sh/acme.sh --installcert -d $domain --keypath /etc/nginx/conf.d/ssl/$domain/privkey.key --fullchainpath /etc/nginx/conf.d/ssl/$domain/fullchain.crt
					echo "SSL installation is complete."
				else
					echo "SSL settings encountered an error, please check again."
				fi
			esac
		fi
	echo "$domain, $wwwdomain not pointing to IP VPS."		
	fi	
	
fi

if [ "$page_speed" == "yes" ] ; then
cat > "/etc/nginx/conf.d/addon_confs/$domain/page_speed.conf" <<END
pagespeed on;
location /ngx_pagespeed_statistics { include conf.d/custom/admin-ips.conf; deny all; }
location /ngx_pagespeed_global_statistics { include conf.d/custom/admin-ips.conf; deny all; }
location /ngx_pagespeed_message { include conf.d/custom/admin-ips.conf; deny all; }
location /pagespeed_console { include conf.d/custom/admin-ips.conf; deny all; }
location /pagespeed_admin { include conf.d/custom/admin-ips.conf; deny all; }
location /pagespeed_global_admin { include conf.d/custom/admin-ips.conf; deny all; }
location ~ "\.pagespeed\.([a-z]\.)?[a-z]{2}\.[^.]{10}\.[^.]+" { add_header "" ""; }
location ~ "^/ngx_pagespeed_static/" { }
location ~ "^/ngx_pagespeed_beacon$" { }
END

fi

total_ram=$(free -m | awk 'NR==2{print $2}')
php_ram=40
pmmax_children=$((total_ram / php_ram))
pmstart_servers=$((pmmax_children * 10 / 100 + 1))
pmmin_spare_servers=$((pmmax_children * 5 / 100 + 1))
pmmax_spare_servers=$((pmmax_children * 20 / 100 + 1))
pmmax_requests=1500

cat > "/opt/php/$php_dir/etc/php-fpm.d/$domain.conf" <<END
[$domain]
listen = /dev/shm/$domain.$php_dir.sock;
user = $user
group = $user
listen.owner = nginx
listen.group = nginx
listen.mode = 0644
pm = ondemand
pm.max_children = $pmmax_children
pm.start_servers = $pmstart_servers
pm.min_spare_servers = $pmmin_spare_servers
pm.max_spare_servers = $pmmax_spare_servers
pm.max_requests = $pmmax_requests
END

cat > "/etc/quicklemp/domains/$domain/php_dir" <<END
$php_dir
END

   cat > "/etc/nginx/conf.d/vhosts/$domain.conf" <<END
server {
        listen 80;
        server_name $domain $domain_alias;
        root /home/$domain/public_html;

	    access_log /home/$domain/logs/access_log main;
	    error_log /home/$domain/logs/error_log warn;

        if (\$bad_bot) { return 444; }
        set \$fpmuser $domain.$php_dir;
         include conf.d/addon_confs/$domain/*.conf;
		include conf.d/custom/wp-rocket.conf; 
}

END

 cat > "/etc/nginx/conf.d/vhosts/$domain.ssl.conf" <<END
server {
        listen 443 ssl http2;
        server_name $domain $domain_alias;
        root /home/$domain/public_html;
		
	    access_log /home/$domain/logs/access_ssl_log main;
	    error_log /home/$domain/logs/error_ssl_log warn;

        if (\$bad_bot) { return 444; }
        set \$fpmuser $domain.$php_dir;

        include conf.d/ssl/$domain/ssl.conf;
        include conf.d/addon_confs/$domain/*.conf;
		include conf.d/custom/wp-rocket.conf;
}
END
cat > "/etc/nginx/conf.d/ssl/$domain/ssl.conf" <<END
ssl_certificate /etc/nginx/conf.d/ssl/$domain/fullchain.crt;
ssl_certificate_key /etc/nginx/conf.d/ssl/$domain/privkey.key;
#ssl_trusted_certificate /etc/nginx/conf.d/ssl/$domain/chain.pem;
ssl_dhparam /etc/nginx/dhparam.pem;
ssl_session_timeout 4h;
ssl_session_cache shared:SSL:20m;
ssl_session_tickets off;
ssl_protocols TLSv1.2 TLSv1.3;
ssl_prefer_server_ciphers on;
#ssl_ecdh_curve X25519:P-256:P-384:P-224:P-521;
ssl_buffer_size 1400;
#ssl_stapling on;
ssl_stapling_verify on;
#ssl_trusted_certificate /etc/nginx/conf.d/ssl/$domain/chain.pem;
resolver 1.1.1.1 8.8.8.8 valid=300s;
resolver_timeout 5s;
add_header Strict-Transport-Security "max-age=63072000; includeSubdomains; preload";
#add_header X-Frame-Options SAMEORIGIN;
add_header X-Content-Type-Options nosniff;

## Modern compatibility
ssl_ciphers TLS13-AES-128-GCM-SHA256:TLS13-AES-256-GCM-SHA384:TLS13-CHACHA20-POLY1305-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA384;

## Intermediate compatibility
#ssl_ciphers TLS13-AES-128-GCM-SHA256:TLS13-AES-256-GCM-SHA384:TLS13-CHACHA20-POLY1305-SHA256:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES256-SHA384:ECDHE-RSA-AES128-SHA:ECDHE-ECDSA-AES256-SHA384:ECDHE-ECDSA-AES256-SHA:ECDHE-RSA-AES256-SHA:DHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA:DHE-RSA-AES256-SHA256:DHE-RSA-AES256-SHA:ECDHE-ECDSA-DES-CBC3-SHA:ECDHE-RSA-DES-CBC3-SHA:EDH-RSA-DES-CBC3-SHA:AES128-GCM-SHA256:AES256-GCM-SHA384:AES128-SHA256:AES256-SHA256:AES128-SHA:AES256-SHA:DES-CBC3-SHA:!DSS;

## Old backward compatibility
#ssl_ciphers ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:DHE-DSS-AES128-GCM-SHA256:kEDH+AESGCM:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA:ECDHE-ECDSA-AES256-SHA:DHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA:DHE-DSS-AES128-SHA256:DHE-RSA-AES256-SHA256:DHE-DSS-AES256-SHA:DHE-RSA-AES256-SHA:ECDHE-RSA-DES-CBC3-SHA:ECDHE-ECDSA-DES-CBC3-SHA:EDH-RSA-DES-CBC3-SHA:AES128-GCM-SHA256:AES256-GCM-SHA384:AES128-SHA256:AES256-SHA256:AES128-SHA:AES256-SHA:AES:DES-CBC3-SHA:HIGH:SEED:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5:!PSK:!RSAPSK:!aDH:!aECDH:!EDH-DSS-DES-CBC3-SHA:!KRB5-DES-CBC3-SHA:!SRP;
END

      fi
if [ "$php_version" = "fpm-laravel-users" ]; then

sed -i "s/$domain\/public_html;/$domain\/public_html\/public;/g" /etc/nginx/conf.d/vhosts/$domain.ssl.conf
sed -i "s/$domain\/public_html;/$domain\/public_html\/public;/g" /etc/nginx/conf.d/vhosts/$domain.conf
fi


##################################################
aliase_file="/etc/quicklemp/domains/$domain/aliase"
if [ -f "$aliase_file" ]; then
    aliase_domain=$(<"$aliase_file")
else
    aliase_domain=""
fi

if [[ -n $aliase_domain && -f "/etc/nginx/conf.d/vhosts/${aliase_domain}.conf" ]]; then
    sed -i "s/$domain\/public_html;/$aliase_domain\/public_html;/g" /etc/nginx/conf.d/vhosts/$domain.ssl.conf
    sed -i "s/$domain\/public_html;/$aliase_domain\/public_html;/g" /etc/nginx/conf.d/vhosts/$domain.conf
	
fi

if ! systemctl is-active --quiet monit; then
yum install monit -y  &>/dev/null

rm -rf /etc/monit.d/*
cat > "/etc/monit.d/logging" <<END
# log to monit.log
set logfile /var/log/monit.log
END
fi

cat > "/etc/monit.d/disk" <<END
check device rootfs with path /
  if space usage > 98% then exec "/bin/bash -c '/usr/bin/find /var/log/messages-* /home/*/logs/access_*.gz /home/*/logs/error_*.gz -delete'"
END
cat > "/etc/monit.d/mysql" <<END
check process mysql with pidfile /var/lib/mysql/sv.pid
  start program = "/usr/bin/systemctl start mysql"
  stop program  = "/usr/bin/systemctl stop mysql"
  if 5 restarts within 5 cycles then timeout
END
cat > "/etc/monit.d/nginx" <<END
check process nginx with pidfile /var/run/nginx.pid
  start program = "/usr/bin/systemctl start nginx"
  stop program  = "/usr/bin/systemctl stop nginx"
END


for dir in /opt/php/php*; do
  if [ -d "$dir" ]; then
    php="${dir##*/}"
    php_ver="${php:3}"
    php_full="php-fpm-${php_ver}"

    cat > "/etc/monit.d/php$php_ver" <<END
check process php$php_ver with pidfile /opt/php/php$php_ver/var/run/php-fpm.pid
  start program = "/usr/bin/systemctl start $php_full"
  stop program = "/usr/bin/systemctl stop $php_full"
END
  fi
done
systemctl restart monit
systemctl enable monit

nginx -s reload  &>/dev/null

##################################################


done



for D in /opt/php/*; do
if [ -d "${D}" ]; then #If a directory
php_version1=${D##*/}
php_ver=${php_version1:3}
service php-fpm-$php_ver restart &>/dev/null
fi
done



#########################

mkdir -p /opt/antiddos

cat >  "/etc/systemd/system/antiddostino.service" <<END
[Unit]
 Description= ON - OFF anti DDOS Layer7
 
[Service]
 ExecStart=/opt/antiddos/checkload

[Install]
 WantedBy=default.target
 
END

cat > "/opt/antiddos/checkload" <<END
#!/bin/sh
while [ 1 -gt 0 ]
do
    num=\$(grep ^cpu\\scores /proc/cpuinfo | uniq |  awk '{print \$4}')
    num=$((num * 4))
    load=\$(cat /proc/loadavg |awk '{print \$1}'|cut -d "." -f1)
    
    if [ "\$load" -gt "\$num" ] && [ "\$load" -gt 10 ]; then
        /usr/sbin/migatedddos on;
        
        topnum=\$(cat /home/*/logs/access*_log | awk -v start="\$(date -d '30 minutes ago' +[%d/%b/%Y:%H:%M:%S])" -v end="\$(date +[%d/%b/%Y:%H:%M:%S])" '\$4 > start && \$4 < end' | awk '{ print \$1}' | sort | uniq -c | sort -nr | head -n 1 |  awk '{ print \$1}')
        topip=\$(cat /home/*/logs/access*_log | awk -v start="\$(date -d '30 minutes ago' +[%d/%b/%Y:%H:%M:%S])" -v end="\$(date +[%d/%b/%Y:%H:%M:%S])" '\$4 > start && \$4 < end' | awk '{ print \$1}' | sort | uniq -c | sort -nr | head -n 1 |  awk '{ print \$2}')
        
        if [ "\$topnum" -gt 3000 ]; then
			csf -e  &> /dev/null
            csf -d  "\$topip"
            echo "\$(date):\$topip:\$topnum"  >> /opt/antiddos/checkload.log
        else
            echo "\$(date)" >> /opt/antiddos/checkload.log
        fi
        
        sleep 900;
        /usr/sbin/migatedddos off;
    fi
    sleep 1;
done
END


cat >  "/usr/sbin/migatedddos" <<END
#!/bin/bash
value=\$1
if [ "\$value" == "on" ]
then
    sed -i '/testcookie\ /s/off/on/' /etc/nginx/conf.d/addon_confs/*/checkcookie.conf
    echo " migatedddos  has been enable from the vhost configuration!"

	
elif [ "\$value" == "off" ]
then
    sed -i '/testcookie\ /s/on/off/' /etc/nginx/conf.d/addon_confs/*/checkcookie.conf
    echo " migatedddos  has been disable from the vhost configuration!"
else
   echo 'Warning: Import the environment variable "on" or "off" to use!'
fi
/usr/sbin/nginx -s reload &>/dev/null

#systemctl restart php-fpm-74.service

for D in /opt/php/*; do
	if [ -d "\${D}" ]; then #If a directory
		php=\${D##*/} # Domain name
		php_ver=\${php:3}
		php_full="php-fpm-\${php_ver}"
	
	echo "restart \$php"
	service php-fpm-\$php_ver restart
fi
done
rm -rf /var/lib/nginx/cache/fastcgi/*

END

chmod +x /etc/systemd/system/antiddostino.service
chmod +x /usr/sbin/migatedddos

systemctl enable antiddostino
systemctl start antiddostino

###################


    service nginx restart



echo ""
echo "All domain rebuild vhosts done !!!**!!!"
/etc/quicklemp/menu/nginx_
